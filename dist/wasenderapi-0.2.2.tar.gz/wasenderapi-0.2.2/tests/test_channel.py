class TestChannel:
    def test_should_have_tests(self):
        assert True == True 